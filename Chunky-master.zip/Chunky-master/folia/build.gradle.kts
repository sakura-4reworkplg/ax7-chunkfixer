repositories {
    maven("https://repo.papermc.io/repository/maven-public/")
}

dependencies {
    compileOnly(group = "dev.folia", name = "folia-api", version = "1.20.2-R0.1-SNAPSHOT")
}
