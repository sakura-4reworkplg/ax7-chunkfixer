package org.popcraft.chunky.integration;

public interface Integration {
}
