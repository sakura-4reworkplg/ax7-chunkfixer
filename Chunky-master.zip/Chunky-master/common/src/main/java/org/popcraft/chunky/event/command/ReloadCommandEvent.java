package org.popcraft.chunky.event.command;

import org.popcraft.chunky.event.Event;

public record ReloadCommandEvent() implements Event {
}
