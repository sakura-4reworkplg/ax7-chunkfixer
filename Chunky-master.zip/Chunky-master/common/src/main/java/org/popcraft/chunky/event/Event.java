package org.popcraft.chunky.event;

public interface Event {
}
